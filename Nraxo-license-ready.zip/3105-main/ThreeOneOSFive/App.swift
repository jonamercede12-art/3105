import SwiftUI
import UIKit
import Foundation
import Security

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            LicenseGateView {
                ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding ? 0 : 1)
                    .allowsHitTesting(!showOnboarding)

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
                }
                .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
                .onOpenURL { url in
                    patchDraftCoordinator.presentImport(url)
                }
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

// MARK: - License gate

/// A stable, per-installation identifier kept in Keychain.
///
/// This deliberately does not use a hardware identifier. A random UUID is
/// generated once and stored with `ThisDeviceOnly`, so it is not synced to
/// iCloud Keychain or restored as a usable identifier onto another device.
enum LicenseDeviceIdentity {
    private static let service = "com.threeoneosfive.license"
    private static let account = "device-id"

    static func identifier() -> String {
        if let existing = read() {
            return existing
        }

        let generated = UUID().uuidString.lowercased()
        let data = Data(generated.utf8)

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]

        let status = SecItemAdd(query as CFDictionary, nil)
        if status == errSecSuccess || status == errSecDuplicateItem {
            return read() ?? generated
        }

        // If Keychain is temporarily unavailable, keep the generated value for
        // this process. The next launch will retry persistence.
        return generated
    }

    private static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else {
            return nil
        }

        return value
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var isChecking = true
    @Published private(set) var isAuthorized = false
    @Published var message: String?

    private let keychainService = "com.threeoneosfive.license"
    private let keychainAccount = "license-key"
    private let validationURL = URL(string: "https://ylupkwemjlzbxhvyfdpl.supabase.co/functions/v1/validate-key")!

    private var deviceID: String?

    func start() {
        Task { await checkStoredKey() }
    }

    func validate(_ key: String) {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else {
            message = "Llave inválida"
            return
        }

        Task { await validateRemote(normalized, saveOnSuccess: true) }
    }

    func clearSavedKey() {
        deleteKeychainValue()
        isAuthorized = false
        message = nil
        isChecking = false
    }

    private func checkStoredKey() async {
        isChecking = true
        message = nil

        let currentDeviceID = LicenseDeviceIdentity.identifier()
        deviceID = currentDeviceID

        guard let storedKey = readKeychainValue() else {
            isChecking = false
            isAuthorized = false
            return
        }

        // A stored key is never trusted locally. It is revalidated against the
        // backend so expiration, activation, and device binding are enforced
        // server-side on every launch.
        await validateRemote(storedKey, saveOnSuccess: false)
    }

    private func validateRemote(_ key: String, saveOnSuccess: Bool) async {
        isChecking = true
        message = nil

        let currentDeviceID = deviceID ?? LicenseDeviceIdentity.identifier()
        deviceID = currentDeviceID

        defer { isChecking = false }

        do {
            var request = URLRequest(url: validationURL)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.timeoutInterval = 15

            // Only public request data is sent from the app. The Supabase
            // service-role key must never be embedded in an iOS binary.
            let body = LicenseValidationRequest(
                key: key,
                deviceID: currentDeviceID
            )
            request.httpBody = try JSONEncoder().encode(body)

            let (data, response) = try await URLSession.shared.data(for: request)

            guard let http = response as? HTTPURLResponse else {
                throw LicenseError.invalidResponse
            }

            // The Edge Function may intentionally use 4xx status codes for
            // business validation failures. Decode its JSON before treating
            // the response as a transport failure.
            if let result = try? JSONDecoder().decode(LicenseResponse.self, from: data) {
                if result.valid {
                    isAuthorized = true
                    if saveOnSuccess {
                        saveKeychainValue(key)
                    }
                    message = nil
                    return
                }

                isAuthorized = false
                deleteKeychainValue()
                message = result.message ?? messageFor(statusCode: http.statusCode)
                return
            }

            guard (200...299).contains(http.statusCode) else {
                throw LicenseError.serverStatus(http.statusCode)
            }

            throw LicenseError.invalidResponse
        } catch is URLError {
            isAuthorized = false
            // Keep a previously saved key when the failure is genuinely a
            // transport problem; do not turn an outage into "Llave inválida".
            message = "No se pudo conectar al servidor"
        } catch {
            isAuthorized = false
            message = "No se pudo conectar al servidor"
        }
    }

    private func messageFor(statusCode: Int) -> String {
        switch statusCode {
        case 404:
            return "Llave inválida"
        case 409:
            return "Llave ya vinculada a otro dispositivo"
        case 410:
            return "Llave expirada"
        default:
            return "Llave inválida"
        }
    }

    private func saveKeychainValue(_ value: String) {
        let data = Data(value.utf8)
        deleteKeychainValue()

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    private func readKeychainValue() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else {
            return nil
        }
        return String(data: data, encoding: .utf8)
    }

    private func deleteKeychainValue() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount
        ]
        SecItemDelete(query as CFDictionary)
    }
}

private struct LicenseValidationRequest: Encodable {
    let key: String
    let deviceID: String

    enum CodingKeys: String, CodingKey {
        case key
        case deviceID = "device_id"
    }
}

private struct LicenseResponse: Decodable {
    let valid: Bool
    let message: String?
}

private enum LicenseError: Error {
    case invalidResponse
    case serverStatus(Int)
}

struct LicenseGateView<Content: View>: View {
    @StateObject private var licenseManager = LicenseManager()
    @State private var key = ""
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        Group {
            if licenseManager.isAuthorized {
                content()
            } else {
                licenseEntryView
            }
        }
        .onAppear { licenseManager.start() }
    }

    private var licenseEntryView: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer()

                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 58))
                    .foregroundStyle(.red)

                Text("Introduce tu llave")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(.white)

                Text("Necesitas una llave válida para acceder a 3105.")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)

                TextField("Llave de acceso", text: $key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled(true)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 16)
                    .frame(height: 52)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.white.opacity(0.12), lineWidth: 1)
                    )

                Button {
                    licenseManager.validate(key)
                } label: {
                    HStack {
                        if licenseManager.isChecking {
                            ProgressView().tint(.white)
                        }
                        Text(licenseManager.isChecking ? "Comprobando..." : "Validar llave")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(licenseManager.isChecking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                if let message = licenseManager.message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red.opacity(0.9))
                        .multilineTextAlignment(.center)
                }

                Spacer()
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 520)
        }
        .onSubmit {
            licenseManager.validate(key)
        }
    }
}

