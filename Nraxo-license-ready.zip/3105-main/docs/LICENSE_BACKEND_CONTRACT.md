# License backend contract

The iOS client calls the existing Supabase Edge Function:

`https://ylupkwemjlzbxhvyfdpl.supabase.co/functions/v1/validate-key`

The request body is JSON:

```json
{
  "key": "LICENSE-KEY",
  "device_id": "uuid-for-this-installation"
}
```

The function should return JSON containing at least:

```json
{
  "valid": true,
  "message": null
}
```

For rejected licenses, `valid` must be `false` and `message` should contain the user-facing reason. The client also maps these HTTP statuses when no JSON message is available:

- `404` → `Llave inválida`
- `409` → `Llave ya vinculada a otro dispositivo`
- `410` → `Llave expirada`

The Supabase service-role key is not used or embedded in the app. Database access and any service-role credential must remain inside the Edge Function/backend.

The backend should perform the key lookup, active/expiry checks, and atomic first-use device binding. A valid request from the same `device_id` must remain valid until the key is disabled or expires.
