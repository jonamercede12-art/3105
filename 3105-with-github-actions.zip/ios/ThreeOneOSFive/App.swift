import SwiftUI
import UIKit
import Foundation
import CoreFoundation
import Security
import Darwin

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            LicenseGateView {
                ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding ? 0 : 1)
                    .allowsHitTesting(!showOnboarding)

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
                }
                .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
                .onOpenURL { url in
                    patchDraftCoordinator.presentImport(url)
                }
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

// MARK: - License gate

private enum LicenseNormalization {
    private static let locale = Locale(identifier: "en_US_POSIX")

    static func key(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(with: locale)
    }

    static func deviceID(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(with: locale)
    }
}

private enum DeviceIdentity {
    private static let service = "com.threeoneosfive.device-identity"
    private static let account = "installation-id"

    /// Uses an app-generated installation identifier stored in Keychain.
    /// No hardware identifier, serial number, UDID, or private MobileGestalt
    /// answer is used for licensing.
    static func current() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data,
           let value = String(data: data, encoding: .utf8) {
            let normalized = LicenseNormalization.deviceID(value)
            if !normalized.isEmpty { return normalized }
        }

        let generated = LicenseNormalization.deviceID(UUID().uuidString)
        let item: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: Data(generated.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]

        let status = SecItemAdd(item as CFDictionary, nil)
        if status == errSecSuccess { return generated }
        if status == errSecDuplicateItem {
            var retryResult: CFTypeRef?
            guard SecItemCopyMatching(query as CFDictionary, &retryResult) == errSecSuccess,
                  let data = retryResult as? Data,
                  let value = String(data: data, encoding: .utf8) else {
                return nil
            }
            let normalized = LicenseNormalization.deviceID(value)
            return normalized.isEmpty ? nil : normalized
        }

        log("license: could not persist installation identity in keychain (\(status))")
        return nil
    }
}


@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var isChecking = true
    @Published private(set) var isAuthorized = false
    @Published private(set) var canActivate = false
    @Published private(set) var hasBoundLicense = false
    @Published var message: String?

    private let bindingMarkerService = "com.threeoneosfive.license-state"
    private let bindingMarkerAccount = "bound-license-id"
    private var hasStarted = false

    func start() {
        guard !hasStarted else { return }
        hasStarted = true
        Task { await checkLicense() }
    }

    func validate(_ key: String) {
        guard !isChecking, canActivate else { return }

        let normalized = LicenseNormalization.key(key)
        guard !normalized.isEmpty else {
            message = "Introduce una llave."
            return
        }

        guard let installationID = DeviceIdentity.current() else {
            message = "No se pudo crear un identificador estable para este dispositivo."
            isAuthorized = false
            return
        }

        isChecking = true
        Task { await activateRemote(normalized, installationID: installationID) }
    }

    func retry() {
        guard !isChecking else { return }
        Task { await checkLicense() }
    }

    private func checkLicense() async {
        isChecking = true
        message = nil
        hasBoundLicense = hasBindingMarker()
        canActivate = !hasBoundLicense

        guard let installationID = DeviceIdentity.current() else {
            finish(
                authorized: false,
                canActivate: false,
                message: "No se pudo crear un identificador estable para este dispositivo."
            )
            return
        }

        do {
            let response = try await LicenseAPI.check(installationID: installationID)
            apply(response)
        } catch {
            handle(error)
        }
    }

    private func activateRemote(_ key: String, installationID: String) async {
        message = nil
        do {
            let response = try await LicenseAPI.activate(
                key: key,
                installationID: installationID
            )
            apply(response)
        } catch {
            handle(error)
        }
    }

    private func apply(_ response: LicenseResponse) {
        hasBoundLicense = response.license != nil || hasBoundLicense
        isChecking = false

        switch response.code {
        case "ACTIVE", "ACTIVATED":
            isAuthorized = true
            canActivate = false
            message = nil
            if let licenseID = response.license?.id {
                saveBindingMarker(licenseID)
            }

        case "NOT_ACTIVATED":
            isAuthorized = false
            hasBoundLicense = false
            canActivate = true
            deleteBindingMarker()
            message = nil

        case "INVALID_LICENSE":
            isAuthorized = false
            canActivate = !hasBoundLicense
            message = response.message ?? "La llave no es válida."

        case "LICENSE_BOUND_ELSEWHERE":
            isAuthorized = false
            canActivate = !hasBoundLicense
            message = response.message ?? "Esta licencia ya está vinculada a otro dispositivo."

        case "EXPIRED", "REVOKED", "DISABLED":
            isAuthorized = false
            canActivate = false
            hasBoundLicense = true
            message = response.message ?? "La licencia de esta instalación no está activa."

        case "DEVICE_ALREADY_BOUND":
            isAuthorized = false
            canActivate = false
            hasBoundLicense = true
            message = response.message ?? "Esta instalación ya tiene una licencia vinculada."

        default:
            isAuthorized = false
            canActivate = !hasBoundLicense
            message = response.message ?? "El servidor devolvió una respuesta no reconocida."
        }
    }

    private func handle(_ error: Error) {
        isChecking = false
        isAuthorized = false
        canActivate = !hasBoundLicense

        if let apiError = error as? LicenseAPIError {
            apply(apiError.response)
            return
        }

        switch error {
        case LicenseError.configurationMissing:
            message = "La aplicación no está configurada para comprobar licencias."
        case LicenseError.invalidResponse:
            message = "El servidor devolvió una respuesta no válida."
        default:
            message = hasBoundLicense
                ? "No se pudo comprobar la licencia. Comprueba tu conexión a Internet."
                : "No se pudo conectar con el servidor."
        }
    }

    private func finish(authorized: Bool, canActivate: Bool, message: String?) {
        isChecking = false
        isAuthorized = authorized
        self.canActivate = canActivate
        self.message = message
    }

    private func hasBindingMarker() -> Bool {
        readKeychainValue(
            service: bindingMarkerService,
            account: bindingMarkerAccount
        ) != nil
    }

    private func saveBindingMarker(_ licenseID: String) {
        saveKeychainValue(
            licenseID,
            service: bindingMarkerService,
            account: bindingMarkerAccount
        )
    }

    private func deleteBindingMarker() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: bindingMarkerService,
            kSecAttrAccount as String: bindingMarkerAccount
        ]
        SecItemDelete(query as CFDictionary)
    }

    private func saveKeychainValue(_ value: String, service: String, account: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let deleteQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(deleteQuery as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    private func readKeychainValue(service: String, account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

private struct LicenseResponse: Decodable {
    let ok: Bool
    let code: String
    let message: String?
    let license: LicenseDetails?
}

private struct LicenseDetails: Decodable {
    let id: String?
    let status: String?
    let activatedAt: String?
    let expiresAt: String?
    let boundAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case status
        case activatedAt = "activated_at"
        case expiresAt = "expires_at"
        case boundAt = "bound_at"
    }
}

private enum LicenseAPI {
    static func check(installationID: String) async throws -> LicenseResponse {
        try await post(
            path: "check",
            body: LicenseCheckRequest(
                installationID: LicenseNormalization.deviceID(installationID)
            )
        )
    }

    static func activate(key: String, installationID: String) async throws -> LicenseResponse {
        try await post(
            path: "activate",
            body: LicenseActivateRequest(
                licenseKey: LicenseNormalization.key(key),
                installationID: LicenseNormalization.deviceID(installationID)
            )
        )
    }

    private static func post<T: Encodable>(path: String, body: T) async throws -> LicenseResponse {
        guard
            let endpointValue = Bundle.main.object(forInfoDictionaryKey: "LicenseAPIBaseURL") as? String,
            let baseEndpoint = URL(string: endpointValue),
            !endpointValue.isEmpty,
            !endpointValue.contains("$("),
            let anonKey = Bundle.main.object(forInfoDictionaryKey: "LicenseAPIAnonKey") as? String,
            !anonKey.isEmpty,
            !anonKey.contains("$(")
        else {
            throw LicenseError.configurationMissing
        }

        var request = URLRequest(url: baseEndpoint.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue(AppInfo.osVersion, forHTTPHeaderField: "X-Client-iOS-Version")
        request.httpBody = try JSONEncoder().encode(body)

        let (data, urlResponse) = try await URLSession.shared.data(for: request)
        guard let httpResponse = urlResponse as? HTTPURLResponse else {
            throw LicenseError.invalidResponse
        }

        guard let response = try? JSONDecoder().decode(LicenseResponse.self, from: data) else {
            throw LicenseError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            throw LicenseAPIError(response: response)
        }

        return response
    }
}

private struct LicenseCheckRequest: Encodable {
    let installationID: String

    enum CodingKeys: String, CodingKey {
        case installationID = "installation_id"
    }
}

private struct LicenseActivateRequest: Encodable {
    let licenseKey: String
    let installationID: String

    enum CodingKeys: String, CodingKey {
        case licenseKey = "license_key"
        case installationID = "installation_id"
    }
}

private struct LicenseAPIError: Error {
    let response: LicenseResponse
}

private enum LicenseError: Error {
    case configurationMissing
    case invalidResponse
}

struct LicenseGateView<Content: View>: View {
    @StateObject private var licenseManager = LicenseManager()
    @State private var key = ""
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        Group {
            if licenseManager.isAuthorized {
                content()
            } else if licenseManager.isChecking {
                checkingView
            } else {
                licenseEntryView
            }
        }
        .onAppear { licenseManager.start() }
    }

    private var checkingView: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 18) {
                ProgressView()
                    .tint(.red)
                    .scaleEffect(1.25)
                Text("Comprobando licencia...")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.7))
            }
        }
    }

    private var licenseEntryView: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer()

                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 58))
                    .foregroundStyle(.red)

                Text(licenseManager.canActivate ? "Introduce tu llave" : "Licencia no disponible")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(.white)

                Text(
                    licenseManager.canActivate
                        ? "Necesitas una llave válida para acceder a 3105."
                        : "Esta instalación ya tiene una licencia vinculada."
                )
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)

                if licenseManager.canActivate {
                    TextField("Llave de acceso", text: $key)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled(true)
                        .textFieldStyle(.plain)
                        .padding(.horizontal, 16)
                        .frame(height: 52)
                        .background(Color.white.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.white.opacity(0.12), lineWidth: 1)
                        )

                    Button {
                        licenseManager.validate(key)
                    } label: {
                        HStack {
                            if licenseManager.isChecking {
                                ProgressView().tint(.white)
                            }
                            Text(licenseManager.isChecking ? "Comprobando..." : "Validar llave")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .disabled(licenseManager.isChecking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } else {
                    Button("Reintentar") {
                        licenseManager.retry()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }

                if let message = licenseManager.message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red.opacity(0.9))
                        .multilineTextAlignment(.center)
                }

                Spacer()
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 520)
        }
        .onSubmit {
            if licenseManager.canActivate {
                licenseManager.validate(key)
            }
        }
    }
}
