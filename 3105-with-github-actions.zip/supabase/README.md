# Sistema de licencias de 3105

Este directorio contiene la migración y la Edge Function que implementan la
relación estricta **una instalación ↔ una licencia**.

## Configuración

1. Ejecuta la migración `migrations/20260829000000_license_binding.sql` en el
   proyecto de Supabase.
2. Despliega la función:

   ```sh
   supabase functions deploy license
   ```

3. La función usa las variables administradas por Supabase:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`

   La Service Role Key solamente vive en el entorno de la Edge Function. No se
   copia en la aplicación iOS.
4. Configura el build de iOS con:
   - `LICENSE_API_BASE_URL=https://<project-ref>.supabase.co/functions/v1/license`
   - `SUPABASE_ANON_KEY=<clave pública anon del proyecto>`

   La clave anon puede viajar en el binario; la Service Role Key no. La
   aplicación envía además `apikey` y `Authorization: Bearer <anon key>` para
   que la función mantenga la verificación JWT activada.

## Flujo de la aplicación

1. La app crea un UUID aleatorio una sola vez y lo guarda en Keychain con
   `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`.
2. En cada inicio envía ese Installation ID a `POST /license/check` (también
   está disponible como `GET /license/check?installation_id=UUID`).
3. La Edge Function calcula el hash SHA-256 y llama a `check_license`.
4. Si no hay vínculo, la app muestra la pantalla existente para introducir la
   llave.
5. La activación envía `installation_id` y `license_key` a
   `POST /license/activate`; `activate_license`
   usa un bloqueo transaccional por instalación y restricciones únicas para
   evitar reclamaciones simultáneas.
6. La app guarda solamente un marcador con el UUID de la licencia para
   controlar el estado de la interfaz. Nunca guarda la llave completa.

El backend es la autoridad: una validación local no habilita el acceso. Un
cliente modificado todavía podría intentar inventar un Installation ID, por lo
que la identidad debe tratarse como una identidad de instalación y no como una
prueba criptográfica de hardware. Para una defensa adicional contra binarios
modificados puede añadirse App Attest en una iteración posterior.

## Crear, revocar y reasignar

Estas operaciones deben ejecutarse desde un panel administrativo o backend
privado autenticado con `service_role`. Nunca expongas esa clave en iOS,
JavaScript público o el navegador.

Crear una licencia:

```sql
select public.admin_create_license('KEY-ABC12345', null);
-- Con vencimiento:
select public.admin_create_license('KEY-ABC12346', '2027-08-29T00:00:00Z');
```

La respuesta incluye el `id`, los últimos cuatro caracteres y el estado, pero
no devuelve ni almacena la llave en texto plano. El usuario puede activar la
llave desde la app; no es necesario introducir el Device ID.

Revocar:

```sql
select public.admin_revoke_license('<license-uuid>');
```

La licencia conserva su vínculo para impedir que se use otra llave en esa
instalación y la app mostrará “La licencia fue revocada”.

Desvincular para que la misma llave pueda ser activada de nuevo:

```sql
select public.admin_unbind_license('<license-uuid>');
```

La siguiente activación establece un nuevo `bound_device_digest` y actualiza
las fechas de activación y vinculación.

Reasignar directamente desde un panel:

```sql
select public.admin_reassign_license(
  '<license-uuid>',
  '<sha256-en-minúsculas-del-installation-id>'
);
```

El panel debe recibir el Installation ID por un canal de soporte controlado y
calcular su SHA-256 antes de invocar esta función. La restricción única
rechaza un dispositivo que ya tenga otra licencia.

## Respuestas de la API

La aplicación llama a la Edge Function `license` con dos rutas:

- `POST /license/check` con `{ "installation_id": "UUID" }`
- `GET /license/check?installation_id=UUID`
- `POST /license/activate` con `{ "installation_id": "UUID", "license_key": "KEY-..." }`

Códigos de negocio: `NOT_ACTIVATED`, `ACTIVE`, `ACTIVATED`, `INVALID_LICENSE`,
`LICENSE_BOUND_ELSEWHERE`, `DEVICE_ALREADY_BOUND`, `EXPIRED`, `REVOKED` y
`DISABLED`.