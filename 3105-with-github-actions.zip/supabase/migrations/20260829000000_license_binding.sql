create extension if not exists pgcrypto with schema extensions;

do $$
begin
  create type public.license_status as enum ('active', 'revoked', 'disabled');
exception
  when duplicate_object then null;
end
$$;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  key_digest text not null unique,
  key_last4 text not null check (key_last4 ~ '^[A-Z0-9]{4}$'),
  status public.license_status not null default 'active',
  activated_at timestamptz,
  expires_at timestamptz,
  bound_device_digest text unique,
  bound_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint licenses_dates_check
    check (bound_device_digest is null or (bound_at is not null and activated_at is not null))
);

create index if not exists licenses_status_idx on public.licenses (status);
create index if not exists licenses_expires_at_idx on public.licenses (expires_at);

alter table public.licenses enable row level security;
revoke all on table public.licenses from public, anon, authenticated;
grant select, insert, update, delete on table public.licenses to service_role;

create or replace function public.license_json(p_license public.licenses)
returns jsonb
language sql
immutable
strict
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'id', p_license.id,
    'status', p_license.status,
    'activated_at', p_license.activated_at,
    'expires_at', p_license.expires_at,
    'bound_at', p_license.bound_at
  );
$$;

create or replace function public.check_license(p_device_digest text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  found_license public.licenses;
begin
  if p_device_digest is null or p_device_digest !~ '^[0-9a-f]{64}$' then
    return jsonb_build_object(
      'ok', false,
      'code', 'INVALID_DEVICE',
      'message', 'El identificador de instalación no es válido.'
    );
  end if;

  select *
    into found_license
    from public.licenses
   where bound_device_digest = p_device_digest
   limit 1;

  if not found then
    return jsonb_build_object(
      'ok', true,
      'code', 'NOT_ACTIVATED',
      'message', 'Esta instalación todavía no tiene una licencia.'
    );
  end if;

  if found_license.status <> 'active' then
    return jsonb_build_object(
      'ok', false,
      'code', upper(found_license.status::text),
      'message', case found_license.status
        when 'revoked' then 'La licencia fue revocada.'
        when 'disabled' then 'La licencia está desactivada.'
        else 'La licencia no está activa.'
      end,
      'license', public.license_json(found_license)
    );
  end if;

  if found_license.expires_at is not null and found_license.expires_at <= now() then
    return jsonb_build_object(
      'ok', false,
      'code', 'EXPIRED',
      'message', 'La licencia está vencida.',
      'license', public.license_json(found_license)
    );
  end if;

  return jsonb_build_object(
    'ok', true,
    'code', 'ACTIVE',
    'license', public.license_json(found_license)
  );
end;
$$;

create or replace function public.activate_license(
  p_key_digest text,
  p_device_digest text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  found_license public.licenses;
  device_license public.licenses;
begin
  if p_key_digest is null or p_key_digest !~ '^[0-9a-f]{64}$'
     or p_device_digest is null or p_device_digest !~ '^[0-9a-f]{64}$' then
    return jsonb_build_object(
      'ok', false,
      'code', 'INVALID_REQUEST',
      'message', 'La solicitud de activación no es válida.'
    );
  end if;

  -- Serialize all claims for the same installation before checking its row.
  -- This closes the race where two different keys are claimed concurrently.
  perform pg_advisory_xact_lock(hashtextextended(p_device_digest, 0));

  select *
    into device_license
    from public.licenses
   where bound_device_digest = p_device_digest
   for update;

  select *
    into found_license
    from public.licenses
   where key_digest = p_key_digest
   for update;

  if not found then
    return jsonb_build_object(
      'ok', false,
      'code', 'INVALID_LICENSE',
      'message', 'La llave no existe o no es válida.'
    );
  end if;

  if device_license.id is not null and device_license.id <> found_license.id then
    return jsonb_build_object(
      'ok', false,
      'code', 'DEVICE_ALREADY_BOUND',
      'message', 'Esta instalación ya tiene una licencia vinculada.'
    );
  end if;

  if found_license.status <> 'active' then
    return jsonb_build_object(
      'ok', false,
      'code', upper(found_license.status::text),
      'message', case found_license.status
        when 'revoked' then 'La licencia fue revocada.'
        when 'disabled' then 'La licencia está desactivada.'
        else 'La licencia no está activa.'
      end,
      'license', public.license_json(found_license)
    );
  end if;

  if found_license.expires_at is not null and found_license.expires_at <= now() then
    return jsonb_build_object(
      'ok', false,
      'code', 'EXPIRED',
      'message', 'La licencia está vencida.',
      'license', public.license_json(found_license)
    );
  end if;

  if found_license.bound_device_digest is not null
     and found_license.bound_device_digest <> p_device_digest then
    return jsonb_build_object(
      'ok', false,
      'code', 'LICENSE_BOUND_ELSEWHERE',
      'message', 'Esta licencia ya está vinculada a otro dispositivo.'
    );
  end if;

  if found_license.bound_device_digest is null then
    update public.licenses
       set bound_device_digest = p_device_digest,
           bound_at = now(),
           activated_at = now(),
           updated_at = now()
     where id = found_license.id
     returning * into found_license;
  end if;

  return jsonb_build_object(
    'ok', true,
    'code', case when device_license.id is null then 'ACTIVATED' else 'ACTIVE' end,
    'license', public.license_json(found_license)
  );
end;
$$;

-- Administrative functions are intentionally not callable by app users.
create or replace function public.admin_create_license(
  p_license_key text,
  p_expires_at timestamptz default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  normalized_key text := upper(trim(p_license_key));
  created_license public.licenses;
begin
  if normalized_key is null
     or normalized_key !~ '^[A-Z0-9][A-Z0-9-]{7,127}$' then
    raise exception 'LICENSE_KEY_FORMAT_INVALID';
  end if;

  insert into public.licenses (key_digest, key_last4, expires_at)
  values (
    encode(digest(normalized_key, 'sha256'), 'hex'),
    right(normalized_key, 4),
    p_expires_at
  )
  returning * into created_license;

  return jsonb_build_object(
    'id', created_license.id,
    'key_last4', created_license.key_last4,
    'status', created_license.status,
    'expires_at', created_license.expires_at
  );
end;
$$;

create or replace function public.admin_revoke_license(p_license_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  changed_license public.licenses;
begin
  update public.licenses
     set status = 'revoked',
         updated_at = now()
   where id = p_license_id
   returning * into changed_license;

  if not found then
    raise exception 'LICENSE_NOT_FOUND';
  end if;

  return public.license_json(changed_license);
end;
$$;

create or replace function public.admin_unbind_license(p_license_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  changed_license public.licenses;
begin
  update public.licenses
     set bound_device_digest = null,
         bound_at = null,
         activated_at = null,
         updated_at = now()
   where id = p_license_id
     and status = 'active'
   returning * into changed_license;

  if not found then
    raise exception 'ACTIVE_LICENSE_NOT_FOUND';
  end if;

  return public.license_json(changed_license);
end;
$$;

create or replace function public.admin_reassign_license(
  p_license_id uuid,
  p_device_digest text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  changed_license public.licenses;
  conflicting_license public.licenses;
begin
  if p_device_digest is null or p_device_digest !~ '^[0-9a-f]{64}$' then
    raise exception 'DEVICE_DIGEST_FORMAT_INVALID';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(p_device_digest, 0));

  select *
    into conflicting_license
    from public.licenses
   where bound_device_digest = p_device_digest
     and id <> p_license_id
   for update;

  if conflicting_license.id is not null then
    raise exception 'DEVICE_ALREADY_BOUND';
  end if;

  update public.licenses
     set bound_device_digest = p_device_digest,
         bound_at = now(),
         activated_at = coalesce(activated_at, now()),
         updated_at = now()
   where id = p_license_id
     and status = 'active'
     and (expires_at is null or expires_at > now())
   returning * into changed_license;

  if not found then
    raise exception 'ACTIVE_LICENSE_NOT_FOUND';
  end if;

  return public.license_json(changed_license);
end;
$$;

revoke all on function public.license_json(public.licenses) from public, anon, authenticated;
revoke all on function public.check_license(text) from public, anon, authenticated;
revoke all on function public.activate_license(text, text) from public, anon, authenticated;
revoke all on function public.admin_create_license(text, timestamptz) from public, anon, authenticated;
revoke all on function public.admin_revoke_license(uuid) from public, anon, authenticated;
revoke all on function public.admin_unbind_license(uuid) from public, anon, authenticated;
revoke all on function public.admin_reassign_license(uuid, text) from public, anon, authenticated;

grant execute on function public.check_license(text) to service_role;
grant execute on function public.activate_license(text, text) to service_role;
grant execute on function public.admin_create_license(text, timestamptz) to service_role;
grant execute on function public.admin_revoke_license(uuid) to service_role;
grant execute on function public.admin_unbind_license(uuid) to service_role;
grant execute on function public.admin_reassign_license(uuid, text) to service_role;