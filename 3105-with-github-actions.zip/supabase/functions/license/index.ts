import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, apikey, content-type, x-client-ios-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Cache-Control": "no-store",
};

type LicenseResponse = {
  ok: boolean;
  code: string;
  message?: string;
  license?: {
    id: string;
    status: string;
    activated_at: string | null;
    expires_at: string | null;
    bound_at: string | null;
  };
};

const json = (body: LicenseResponse, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const normalize = (value: unknown): string | null => {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toUpperCase();
  return normalized.length > 0 ? normalized : null;
};

const sha256 = async (value: string): Promise<string> => {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
};

const statusFor = (code: string): number => {
  if (code === "ACTIVATED") return 201;
  if (code === "LICENSE_BOUND_ELSEWHERE" || code === "DEVICE_ALREADY_BOUND")
    return 409;
  if (code === "INVALID_LICENSE") return 422;
  if (code === "INVALID_REQUEST" || code === "INVALID_DEVICE") return 400;
  return 200;
};

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (request.method !== "GET" && request.method !== "POST") {
    return json(
      {
        ok: false,
        code: "METHOD_NOT_ALLOWED",
        message: "Método no permitido.",
      },
      405,
    );
  }

  if (!supabaseUrl || !serviceRoleKey) {
    return json(
      {
        ok: false,
        code: "SERVER_MISCONFIGURED",
        message: "El servicio de licencias no está configurado.",
      },
      500,
    );
  }

  const url = new URL(request.url);
  let body: Record<string, unknown> = {};
  if (request.method === "GET") {
    body.installation_id = url.searchParams.get("installation_id");
  } else {
    try {
      body = await request.json();
    } catch {
      return json(
        {
          ok: false,
          code: "INVALID_REQUEST",
          message: "El cuerpo de la solicitud no es válido.",
        },
        400,
      );
    }
  }

  const installationID = normalize(body.installation_id);
  if (
    !installationID ||
    !/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/.test(
      installationID,
    )
  ) {
    return json(
      {
        ok: false,
        code: "INVALID_DEVICE",
        message: "El identificador de instalación no es válido.",
      },
      400,
    );
  }

  const client = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const deviceDigest = await sha256(installationID);

  const isActivatePath = url.pathname.endsWith("/activate");
  const isCheckPath = url.pathname.endsWith("/check");

  if (isCheckPath || (!isActivatePath && body.license_key === undefined)) {
    const { data, error } = await client.rpc("check_license", {
      p_device_digest: deviceDigest,
    });

    if (error || !data || typeof data !== "object") {
      return json(
        {
          ok: false,
          code: "SERVER_ERROR",
          message: "No se pudo comprobar la licencia.",
        },
        500,
      );
    }

    return json(data as LicenseResponse);
  }

  if (!isActivatePath && body.license_key === undefined) {
    return json(
      {
        ok: false,
        code: "INVALID_REQUEST",
        message: "Indica si deseas comprobar o activar la licencia.",
      },
      400,
    );
  }

  const licenseKey = normalize(body.license_key);
  if (!licenseKey || !/^[A-Z0-9][A-Z0-9-]{7,127}$/.test(licenseKey)) {
    return json(
      {
        ok: false,
        code: "INVALID_LICENSE",
        message: "La llave no existe o no es válida.",
      },
      422,
    );
  }

  const { data, error } = await client.rpc("activate_license", {
    p_key_digest: await sha256(licenseKey),
    p_device_digest: deviceDigest,
  });

  if (error || !data || typeof data !== "object") {
    return json(
      {
        ok: false,
        code: "SERVER_ERROR",
        message: "No se pudo activar la licencia.",
      },
      500,
    );
  }

  const response = data as LicenseResponse;
  return json(response, statusFor(response.code));
});
