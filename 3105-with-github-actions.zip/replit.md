# 3105 Licencias por instalación

Fuente iOS de 3105 con validación de licencias vinculada de forma atómica a cada instalación y respaldada por Supabase.

## Run & Operate

- El cliente iOS se encuentra en `ios/ThreeOneOSFive.xcodeproj`.
- Las migraciones y Edge Functions de Supabase se encuentran en `supabase/`.
- La compilación de iOS se ejecuta en GitHub Actions sobre macOS.
- Revisa `supabase/README.md` antes de desplegar la función o ejecutar la migración.

## Stack

- Aplicación nativa SwiftUI para iOS 16+.
- Supabase PostgreSQL con RLS, funciones SQL SECURITY DEFINER y Edge Functions Deno.
- El cliente solo usa la clave pública anon y nunca contiene `SUPABASE_SERVICE_ROLE_KEY`.

## Where things live

- `ios/ThreeOneOSFive/App.swift` — gate de licencia, Installation ID y cliente HTTP.
- `ios/ThreeOneOSFive/Info.plist` — variables de build `LicenseAPIBaseURL` y `LicenseAPIAnonKey`.
- `supabase/migrations/20260829000000_license_binding.sql` — esquema, restricciones y RPC.
- `supabase/functions/license/index.ts` — rutas `/check` y `/activate`.
- `supabase/README.md` — despliegue, respuestas y operaciones administrativas.

## Architecture decisions

- Se usa un UUID aleatorio generado por la app y almacenado en Keychain `ThisDeviceOnly`, no identificadores de hardware ni APIs privadas.
- La base guarda hashes SHA-256 de la llave y del Installation ID; la llave completa nunca se persiste.
- Un bloqueo transaccional por Installation ID y restricciones únicas garantizan un vínculo uno-a-uno.
- El estado se consulta al iniciar; el cliente no decide localmente si una licencia es válida.

## Product

3105 conserva su workspace nativo, parches, limpieza y wallpaper lab. El acceso
se habilita solo cuando Supabase confirma una licencia activa vinculada a la instalación.

## User preferences

No cambiar el diseño visual ni las funciones no relacionadas con licencias.

## Gotchas

- Deben configurarse `LICENSE_API_BASE_URL` y `SUPABASE_ANON_KEY` en cada build de iOS.
- `SUPABASE_SERVICE_ROLE_KEY` solo debe existir en Supabase; nunca se agrega al proyecto iOS.
- No se debe otorgar acceso directo a `public.licenses` a `anon` o `authenticated`.

## Pointers

- `supabase/README.md` es la guía operativa del sistema de licencias.
