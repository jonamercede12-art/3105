import SwiftUI
import UIKit
import Foundation
import CoreFoundation
import Security
import Darwin

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            LicenseGateView {
                ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding ? 0 : 1)
                    .allowsHitTesting(!showOnboarding)

                if showOnboarding {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
                }
                .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
                .onOpenURL { url in
                    patchDraftCoordinator.presentImport(url)
                }
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

// MARK: - License gate

private enum LicenseNormalization {
    private static let locale = Locale(identifier: "en_US_POSIX")

    static func key(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(with: locale)
    }

    static func deviceID(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(with: locale)
    }
}

private enum DeviceIdentity {
    private typealias MGCopyAnswerFunction = @convention(c) (CFString) -> Unmanaged<CFTypeRef>?
    private static let libraryPaths = [
        "/usr/lib/libMobileGestalt.dylib",
        "/System/Library/PrivateFrameworks/MobileGestalt.framework/MobileGestalt"
    ]
    private static let answerKeys = [
        "UniqueDeviceID",
        "UniqueDeviceIDData"
    ]

    /// Returns the same hardware identifier format used by the license service.
    ///
    /// identifierForVendor is intentionally not used here: it is an app-scoped
    /// UUID and would not match the device identifiers stored by the service.
    static func current() -> String? {
        #if targetEnvironment(simulator)
        if let override = ProcessInfo.processInfo.environment["THREEONEOSFIVE_DEVICE_ID"] {
            let normalized = LicenseNormalization.deviceID(override)
            return normalized.isEmpty ? nil : normalized
        }
        return nil
        #else
        for path in libraryPaths {
            guard let handle = dlopen(path, RTLD_LAZY) else { continue }
            defer { dlclose(handle) }

            guard let symbol = dlsym(handle, "MGCopyAnswer") else { continue }
            let copyAnswer = unsafeBitCast(symbol, to: MGCopyAnswerFunction.self)

            for answer in answerKeys {
                guard let unmanagedValue = copyAnswer(answer as CFString) else { continue }
                let value = unmanagedValue.takeRetainedValue()

                if let identifier = identifier(from: value) {
                    log("license: MobileGestalt identifier obtained from \(answer)")
                    return identifier
                }
            }
        }

        log("license: MobileGestalt unavailable or returned no usable device identity")
        return nil
        #endif
    }

    private static func identifier(from value: CFTypeRef) -> String? {
        if let string = value as? String {
            let normalized = LicenseNormalization.deviceID(string)
            return normalized.isEmpty ? nil : normalized
        }

        // Some iOS versions bridge the answer as NSString rather than String.
        if let string = value as? NSString {
            let normalized = LicenseNormalization.deviceID(string as String)
            return normalized.isEmpty ? nil : normalized
        }

        // UniqueDeviceIDData is returned as CFData on some releases.
        if let data = value as? Data, !data.isEmpty {
            let hex = data.map { String(format: "%02X", $0) }.joined()
            return hex.isEmpty ? nil : hex
        }

        if let uuid = value as? NSUUID {
            return LicenseNormalization.deviceID(uuid.uuidString)
        }

        return nil
    }
}


@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var isChecking = true
    @Published private(set) var isAuthorized = false
    @Published var message: String?

    private let keychainService = "com.threeoneosfive.license"
    private let keychainAccount = "license-key"
    private let validationURL = URL(string: "https://ylupkwemjlzbxhvyfdpl.supabase.co/functions/v1/validate-key")!

    func start() {
        Task { await checkStoredKey() }
    }

    func validate(_ key: String) {
        guard !isChecking else { return }

        let normalized = LicenseNormalization.key(key)
        guard !normalized.isEmpty else {
            message = "Introduce una llave."
            return
        }

        guard let deviceID = DeviceIdentity.current() else {
            message = "No se pudo obtener el identificador de este dispositivo."
            isAuthorized = false
            return
        }

        isChecking = true
        Task { await validateRemote(normalized, deviceID: deviceID, saveOnSuccess: true) }
    }

    func clearSavedKey() {
        deleteKeychainValue()
        isAuthorized = false
        message = nil
        isChecking = false
    }

    private func checkStoredKey() async {
        isChecking = true
        message = nil
        guard let storedKey = readKeychainValue() else {
            isChecking = false
            isAuthorized = false
            return
        }

        guard let deviceID = DeviceIdentity.current() else {
            isChecking = false
            isAuthorized = false
            message = "No se pudo obtener el identificador de este dispositivo."
            return
        }

        await validateRemote(
            LicenseNormalization.key(storedKey),
            deviceID: deviceID,
            saveOnSuccess: false
        )
    }

    private func validateRemote(_ key: String, deviceID: String, saveOnSuccess: Bool) async {
        isChecking = true
        message = nil
        defer { isChecking = false }

        do {
            var request = URLRequest(url: validationURL)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.timeoutInterval = 15
            request.httpBody = try JSONEncoder().encode([
                "key": LicenseNormalization.key(key),
                "device_id": LicenseNormalization.deviceID(deviceID)
            ])

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw LicenseError.invalidResponse
            }

            guard (200...299).contains(http.statusCode) else {
                throw LicenseError.serverStatus(http.statusCode)
            }

            let result = try JSONDecoder().decode(LicenseResponse.self, from: data)
            isAuthorized = result.valid

            if result.valid {
                if saveOnSuccess { saveKeychainValue(key) }
                message = nil
            } else {
                deleteKeychainValue()
                message = result.message ?? "Llave inválida."
            }
        } catch {
            isAuthorized = false
            if readKeychainValue() != nil {
                message = "No se pudo comprobar la llave. Comprueba tu conexión a Internet."
            } else {
                message = "No se pudo conectar con el servidor."
            }
        }
    }

    private func saveKeychainValue(_ value: String) {
        let data = Data(value.utf8)
        deleteKeychainValue()

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    private func readKeychainValue() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deleteKeychainValue() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount
        ]
        SecItemDelete(query as CFDictionary)
    }
}

private struct LicenseResponse: Decodable {
    let valid: Bool
    let message: String?
}

private enum LicenseError: Error {
    case invalidResponse
    case serverStatus(Int)
}

struct LicenseGateView<Content: View>: View {
    @StateObject private var licenseManager = LicenseManager()
    @State private var key = ""
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        Group {
            if licenseManager.isAuthorized {
                content()
            } else {
                licenseEntryView
            }
        }
        .onAppear { licenseManager.start() }
    }

    private var licenseEntryView: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer()

                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 58))
                    .foregroundStyle(.red)

                Text("Introduce tu llave")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(.white)

                Text("Necesitas una llave válida para acceder a 3105.")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)

                TextField("Llave de acceso", text: $key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled(true)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 16)
                    .frame(height: 52)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.white.opacity(0.12), lineWidth: 1)
                    )

                Button {
                    licenseManager.validate(key)
                } label: {
                    HStack {
                        if licenseManager.isChecking {
                            ProgressView().tint(.white)
                        }
                        Text(licenseManager.isChecking ? "Comprobando..." : "Validar llave")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(licenseManager.isChecking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                if let message = licenseManager.message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red.opacity(0.9))
                        .multilineTextAlignment(.center)
                }

                Spacer()
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 520)
        }
        .onSubmit {
            licenseManager.validate(key)
        }
    }
}
