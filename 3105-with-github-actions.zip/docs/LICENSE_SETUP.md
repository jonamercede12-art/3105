# 3105 license system

The app sends this JSON to the Supabase Edge Function:

```json
{
  "key": "KRXM4-...",
  "device_id": "APP_DEVICE_ID"
}
```

`device_id` is an app-owned persistent identifier. iOS does not expose the physical UDID to ordinary apps.

The server must validate:

1. `key` exists.
2. `active = true`.
3. `device_id` equals the request's `device_id`.
4. `expires_at` is null or is in the future.

Do not put the Supabase service-role key in the iOS app.
